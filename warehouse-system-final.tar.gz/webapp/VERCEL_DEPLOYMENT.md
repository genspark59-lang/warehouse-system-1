# 🚀 دليل نشر نظام المستودعات على Vercel

## ✅ الخطوات المطلوبة (10 دقائق فقط!)

### 1️⃣ إنشاء حساب GitHub (إذا لم يكن لديك)
- اذهب إلى: https://github.com/signup
- سجل حساب جديد (مجاني)
- فعّل إيميلك

### 2️⃣ رفع الكود على GitHub

**الطريقة الأولى: من خلال GitHub Web:**
1. اذهب إلى: https://github.com/new
2. اسم المشروع: `warehouse-system`
3. اختر: **Public** أو **Private** (كلاهما يعمل)
4. **لا تختر** "Initialize with README"
5. اضغط **"Create repository"**

6. **ارفع الملفات:**
   - اضغط "uploading an existing file"
   - اسحب كل ملفات المشروع من `/home/user/webapp`
   - أو استخدم الأوامر التالية (إذا كان GitHub متصل):

```bash
cd /home/user/webapp
git remote add origin https://github.com/YOUR_USERNAME/warehouse-system.git
git branch -M main
git push -u origin main
```

**الطريقة الثانية: رفع يدوي (الأسهل):**
1. حمّل كل ملفات المشروع من `/home/user/webapp`
2. ارفعها على GitHub من المتصفح

---

### 3️⃣ إنشاء حساب Vercel
- اذهب إلى: https://vercel.com/signup
- سجل دخول **باستخدام GitHub** (أسهل طريقة)
- اقبل الصلاحيات المطلوبة

---

### 4️⃣ ربط المشروع مع Vercel

1. **بعد تسجيل الدخول في Vercel:**
   - اضغط **"Add New..."** → **"Project"**

2. **Import Git Repository:**
   - راح تشوف قائمة بمشاريعك في GitHub
   - اختر: `warehouse-system`
   - اضغط **"Import"**

3. **Configure Project:**
   - **Framework Preset**: اختر "Other" أو اتركها فاضية
   - **Build Command**: `npm run build` (موجودة تلقائياً)
   - **Output Directory**: `public`
   - **Install Command**: `npm install`

4. **Environment Variables** (مهم جداً!):
   - اضغط **"Environment Variables"**
   - احتاج تضيف متغيرات قاعدة البيانات لاحقاً

5. **اضغط "Deploy"**
   - انتظر 2-3 دقائق
   - راح يفشل أول مرة! (طبيعي، لأن ما فيه قاعدة بيانات بعد)

---

### 5️⃣ إنشاء قاعدة بيانات على Neon

1. **اذهب إلى Neon:**
   - https://neon.tech
   - سجل دخول بـ GitHub

2. **Create New Project:**
   - اسم المشروع: `warehouse-db`
   - Region: اختر الأقرب لك (مثل: AWS - EU West)
   - اضغط **"Create Project"**

3. **Get Connection String:**
   - راح تشوف **Connection String**
   - انسخ الـ **Connection String** كامل
   - مثال: `postgresql://user:password@ep-xxx.us-east-2.aws.neon.tech/neondb?sslmode=require`

---

### 6️⃣ إضافة قاعدة البيانات لـ Vercel

1. **ارجع لـ Vercel Dashboard:**
   - اختر مشروعك `warehouse-system`
   - اضغط **"Settings"** → **"Environment Variables"**

2. **أضف المتغيرات:**

**المتغير الأول:**
- **Name**: `POSTGRES_URL`
- **Value**: الصق الـ Connection String من Neon
- **Environment**: اختر `Production`, `Preview`, `Development` (الثلاثة)
- اضغط **"Save"**

**المتغير الثاني:**
- **Name**: `POSTGRES_PRISMA_URL`
- **Value**: نفس الـ Connection String (أضف `?pgbouncer=true` في النهاية)
- **Environment**: الثلاثة
- اضغط **"Save"**

**المتغير الثالث:**
- **Name**: `POSTGRES_URL_NON_POOLING`
- **Value**: نفس الـ Connection String الأصلي
- **Environment**: الثلاثة
- اضغط **"Save"**

---

### 7️⃣ إعادة Deploy

1. **في Vercel:**
   - اذهب إلى **"Deployments"**
   - اضغط على آخر deployment
   - اضغط على الثلاث نقاط **"..."**
   - اختر **"Redeploy"**
   - انتظر 2-3 دقائق

---

### 8️⃣ تهيئة قاعدة البيانات

1. **بعد نجاح الـ Deploy:**
   - راح تحصل على رابط مثل: `https://warehouse-system.vercel.app`
   
2. **افتح المتصفح:**
   - اذهب إلى: `https://YOUR-PROJECT.vercel.app/api/init-db`
   - المفروض تشوف: `{"success":true,"message":"Database initialized"}`

3. **افتح النظام:**
   - اذهب إلى: `https://YOUR-PROJECT.vercel.app`
   - استمتع بنظام المستودعات! 🎉

---

## ✅ النتيجة النهائية:

- ✅ رابط دائم: `https://warehouse-system-xxx.vercel.app`
- ✅ قاعدة بيانات PostgreSQL دائمة
- ✅ يعمل 24/7 بدون توقف
- ✅ مجاني تماماً
- ✅ SSL مجاني (HTTPS)
- ✅ سريع جداً (CDN عالمي)

---

## 🔧 إذا واجهت مشاكل:

### المشكلة: Deploy فشل
**الحل:**
- تحقق من Environment Variables
- تأكد أن الـ Connection String صحيح
- شوف الـ logs في Vercel

### المشكلة: API لا يعمل
**الحل:**
- افتح `/api/init-db` أولاً
- تحقق من قاعدة البيانات في Neon

### المشكلة: لا توجد بيانات
**الحل:**
- افتح `/api/init-db` لتهيئة الجداول
- أضف بيانات جديدة من الواجهة

---

## 📱 للدعم:

إذا احتجت مساعدة، أخبرني! 🤝

---

**آخر تحديث:** 2025-11-29
**الحالة:** ✅ جاهز للنشر
