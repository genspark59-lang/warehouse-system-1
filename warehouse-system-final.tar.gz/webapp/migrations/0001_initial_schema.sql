-- جدول أنواع الأجهزة
CREATE TABLE IF NOT EXISTS device_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- جدول المشتريات (المدخلات)
CREATE TABLE IF NOT EXISTS purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_date DATE NOT NULL,
  device_type TEXT NOT NULL,
  model TEXT,
  box_count INTEGER NOT NULL DEFAULT 0,
  piece_count INTEGER NOT NULL DEFAULT 0,
  imei TEXT,
  invoice_number TEXT,
  storage_status TEXT DEFAULT 'في المخزن',
  customs_declaration TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- جدول المبيعات (المخرجات)
CREATE TABLE IF NOT EXISTS sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_date DATE NOT NULL,
  device_type TEXT NOT NULL,
  model TEXT,
  box_count INTEGER NOT NULL DEFAULT 0,
  piece_count INTEGER NOT NULL DEFAULT 0,
  invoice_number TEXT NOT NULL,
  transfer_status TEXT DEFAULT 'تم النقل',
  imei TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- جدول ما بعد البيع
CREATE TABLE IF NOT EXISTS after_sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id INTEGER,
  has_imei BOOLEAN DEFAULT 0,
  imei TEXT,
  customs_declaration TEXT,
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
);

-- إنشاء فهارس للبحث السريع
CREATE INDEX IF NOT EXISTS idx_purchases_device_type ON purchases(device_type);
CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date);
CREATE INDEX IF NOT EXISTS idx_sales_device_type ON sales(device_type);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_after_sales_sale_id ON after_sales(sale_id);

-- إدخال بيانات تجريبية لأنواع الأجهزة
INSERT OR IGNORE INTO device_types (name) VALUES 
  ('iPhone'),
  ('Samsung'),
  ('Xiaomi'),
  ('Huawei'),
  ('Oppo'),
  ('Vivo');
