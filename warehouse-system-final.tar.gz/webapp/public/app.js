// Global state
let currentEditId = null;
let currentEditType = null;

// Page navigation
function showPage(pageName) {
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.add('hidden'));
    
    const targetPage = document.getElementById(`${pageName}-page`);
    if (targetPage) {
        targetPage.classList.remove('hidden');
        
        // Load data for the page
        if (pageName === 'dashboard') {
            loadDashboardStats();
        } else if (pageName === 'purchases') {
            loadPurchases();
        } else if (pageName === 'sales') {
            loadSales();
        } else if (pageName === 'reports') {
            loadReports();
        }
    }
}

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const response = await axios.get('/api/dashboard/stats');
        if (response.data.success) {
            const { purchases, sales, remaining } = response.data.data;
            
            document.getElementById('total-purchase-boxes').textContent = purchases.box_count || 0;
            document.getElementById('total-purchase-pieces').textContent = purchases.piece_count || 0;
            document.getElementById('total-sale-boxes').textContent = sales.box_count || 0;
            document.getElementById('total-sale-pieces').textContent = sales.piece_count || 0;
            document.getElementById('remaining-boxes').textContent = remaining.box_count || 0;
            document.getElementById('remaining-pieces').textContent = remaining.piece_count || 0;
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        alert('حدث خطأ في تحميل الإحصائيات');
    }
}

// Load purchases
async function loadPurchases() {
    try {
        const response = await axios.get('/api/purchases');
        if (response.data.success) {
            const tbody = document.getElementById('purchases-table-body');
            tbody.innerHTML = '';
            
            response.data.data.forEach(purchase => {
                const row = `
                    <tr class="table-row">
                        <td class="px-6 py-4">${purchase.purchase_date}</td>
                        <td class="px-6 py-4">${purchase.device_type}</td>
                        <td class="px-6 py-4">${purchase.model || '-'}</td>
                        <td class="px-6 py-4">${purchase.box_count}</td>
                        <td class="px-6 py-4">${purchase.piece_count}</td>
                        <td class="px-6 py-4">${purchase.invoice_number || '-'}</td>
                        <td class="px-6 py-4">
                            <span class="px-3 py-1 rounded-full text-sm ${getStatusColor(purchase.storage_status)}">
                                ${purchase.storage_status}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <button onclick="editPurchase(${purchase.id})" class="text-blue-600 hover:text-blue-800 mx-2">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="deletePurchase(${purchase.id})" class="text-red-600 hover:text-red-800 mx-2">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += row;
            });
        }
    } catch (error) {
        console.error('Error loading purchases:', error);
        alert('حدث خطأ في تحميل المشتريات');
    }
}

// Load sales
async function loadSales() {
    try {
        const response = await axios.get('/api/sales');
        if (response.data.success) {
            const tbody = document.getElementById('sales-table-body');
            tbody.innerHTML = '';
            
            response.data.data.forEach(sale => {
                const row = `
                    <tr class="table-row">
                        <td class="px-6 py-4">${sale.sale_date}</td>
                        <td class="px-6 py-4">${sale.device_type}</td>
                        <td class="px-6 py-4">${sale.model || '-'}</td>
                        <td class="px-6 py-4">${sale.box_count}</td>
                        <td class="px-6 py-4">${sale.piece_count}</td>
                        <td class="px-6 py-4">${sale.invoice_number}</td>
                        <td class="px-6 py-4">
                            <span class="px-3 py-1 rounded-full text-sm ${getStatusColor(sale.transfer_status)}">
                                ${sale.transfer_status}
                            </span>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <button onclick="editSale(${sale.id})" class="text-blue-600 hover:text-blue-800 mx-2">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button onclick="deleteSale(${sale.id})" class="text-red-600 hover:text-red-800 mx-2">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += row;
            });
        }
    } catch (error) {
        console.error('Error loading sales:', error);
        alert('حدث خطأ في تحميل المبيعات');
    }
}

// Load reports
async function loadReports() {
    try {
        const response = await axios.get('/api/reports/by-device');
        if (response.data.success) {
            const tbody = document.getElementById('reports-table-body');
            tbody.innerHTML = '';
            
            response.data.data.forEach(report => {
                const statusClass = report.remaining_pieces > 20 ? 'bg-green-100 text-green-800' : 
                                   report.remaining_pieces > 0 ? 'bg-yellow-100 text-yellow-800' : 
                                   'bg-red-100 text-red-800';
                const statusText = report.remaining_pieces > 20 ? 'متوفر' : 
                                  report.remaining_pieces > 0 ? 'قليل' : 
                                  'نفذ';
                
                const row = `
                    <tr class="table-row">
                        <td class="px-6 py-4 font-semibold">${report.device_type}</td>
                        <td class="px-6 py-4">${report.purchase_boxes}</td>
                        <td class="px-6 py-4">${report.purchase_pieces}</td>
                        <td class="px-6 py-4">${report.sale_boxes}</td>
                        <td class="px-6 py-4">${report.sale_pieces}</td>
                        <td class="px-6 py-4 font-bold">${report.remaining_pieces}</td>
                        <td class="px-6 py-4">
                            <div class="flex items-center">
                                <div class="w-full bg-gray-200 rounded-full h-2.5 ml-2">
                                    <div class="bg-purple-600 h-2.5 rounded-full" style="width: ${report.sale_percentage}%"></div>
                                </div>
                                <span class="text-sm font-medium">${report.sale_percentage}%</span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-center">
                            <span class="px-3 py-1 rounded-full text-sm ${statusClass}">
                                ${statusText}
                            </span>
                        </td>
                    </tr>
                `;
                tbody.innerHTML += row;
            });
        }
    } catch (error) {
        console.error('Error loading reports:', error);
        alert('حدث خطأ في تحميل التقارير');
    }
}

// Load device types for dropdowns
async function loadDeviceTypes() {
    try {
        const response = await axios.get('/api/device-types');
        if (response.data.success) {
            const datalist1 = document.getElementById('device-types-list');
            const datalist2 = document.getElementById('device-types-list-sale');
            datalist1.innerHTML = '';
            datalist2.innerHTML = '';
            
            response.data.data.forEach(type => {
                const option1 = document.createElement('option');
                option1.value = type.name;
                datalist1.appendChild(option1);
                
                const option2 = document.createElement('option');
                option2.value = type.name;
                datalist2.appendChild(option2);
            });
        }
    } catch (error) {
        console.error('Error loading device types:', error);
    }
}

// Purchase Modal functions
function openPurchaseModal(editData = null) {
    currentEditId = editData ? editData.id : null;
    currentEditType = 'purchase';
    
    const modal = document.getElementById('purchase-modal');
    const title = document.getElementById('purchase-modal-title');
    
    if (editData) {
        title.textContent = 'تعديل المشتريات';
        document.getElementById('purchase-id').value = editData.id;
        document.getElementById('purchase-date').value = editData.purchase_date;
        document.getElementById('purchase-device-type').value = editData.device_type;
        document.getElementById('purchase-model').value = editData.model || '';
        document.getElementById('purchase-box-count').value = editData.box_count;
        document.getElementById('purchase-piece-count').value = editData.piece_count;
        document.getElementById('purchase-imei').value = editData.imei || '';
        document.getElementById('purchase-invoice').value = editData.invoice_number || '';
        document.getElementById('purchase-storage-status').value = editData.storage_status || 'في المخزن';
        document.getElementById('purchase-customs').value = editData.customs_declaration || '';
        document.getElementById('purchase-notes').value = editData.notes || '';
    } else {
        title.textContent = 'إضافة مشتريات جديدة';
        document.getElementById('purchase-form').reset();
        document.getElementById('purchase-date').value = new Date().toISOString().split('T')[0];
    }
    
    modal.classList.add('active');
}

function closePurchaseModal() {
    const modal = document.getElementById('purchase-modal');
    modal.classList.remove('active');
    document.getElementById('purchase-form').reset();
    currentEditId = null;
}

async function editPurchase(id) {
    try {
        const response = await axios.get('/api/purchases');
        if (response.data.success) {
            const purchase = response.data.data.find(p => p.id === id);
            if (purchase) {
                openPurchaseModal(purchase);
            }
        }
    } catch (error) {
        console.error('Error loading purchase:', error);
        alert('حدث خطأ في تحميل بيانات المشتريات');
    }
}

async function deletePurchase(id) {
    if (!confirm('هل أنت متأكد من حذف هذه المشتريات؟')) return;
    
    try {
        const response = await axios.delete(`/api/purchases/${id}`);
        if (response.data.success) {
            alert('تم حذف المشتريات بنجاح');
            loadPurchases();
            loadDashboardStats();
        }
    } catch (error) {
        console.error('Error deleting purchase:', error);
        alert('حدث خطأ في حذف المشتريات');
    }
}

// Sale Modal functions
function openSaleModal(editData = null) {
    currentEditId = editData ? editData.id : null;
    currentEditType = 'sale';
    
    const modal = document.getElementById('sale-modal');
    const title = document.getElementById('sale-modal-title');
    
    if (editData) {
        title.textContent = 'تعديل المبيعات';
        document.getElementById('sale-id').value = editData.id;
        document.getElementById('sale-date').value = editData.sale_date;
        document.getElementById('sale-device-type').value = editData.device_type;
        document.getElementById('sale-model').value = editData.model || '';
        document.getElementById('sale-box-count').value = editData.box_count;
        document.getElementById('sale-piece-count').value = editData.piece_count;
        document.getElementById('sale-invoice').value = editData.invoice_number;
        document.getElementById('sale-transfer-status').value = editData.transfer_status || 'تم النقل';
        document.getElementById('sale-imei').value = editData.imei || '';
        document.getElementById('sale-notes').value = editData.notes || '';
    } else {
        title.textContent = 'إضافة مبيعات جديدة';
        document.getElementById('sale-form').reset();
        document.getElementById('sale-date').value = new Date().toISOString().split('T')[0];
    }
    
    modal.classList.add('active');
}

function closeSaleModal() {
    const modal = document.getElementById('sale-modal');
    modal.classList.remove('active');
    document.getElementById('sale-form').reset();
    currentEditId = null;
}

async function editSale(id) {
    try {
        const response = await axios.get('/api/sales');
        if (response.data.success) {
            const sale = response.data.data.find(s => s.id === id);
            if (sale) {
                openSaleModal(sale);
            }
        }
    } catch (error) {
        console.error('Error loading sale:', error);
        alert('حدث خطأ في تحميل بيانات المبيعات');
    }
}

async function deleteSale(id) {
    if (!confirm('هل أنت متأكد من حذف هذه المبيعات؟')) return;
    
    try {
        const response = await axios.delete(`/api/sales/${id}`);
        if (response.data.success) {
            alert('تم حذف المبيعات بنجاح');
            loadSales();
            loadDashboardStats();
        }
    } catch (error) {
        console.error('Error deleting sale:', error);
        alert('حدث خطأ في حذف المبيعات');
    }
}

// Form submissions
document.getElementById('purchase-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        purchase_date: document.getElementById('purchase-date').value,
        device_type: document.getElementById('purchase-device-type').value,
        model: document.getElementById('purchase-model').value,
        box_count: parseInt(document.getElementById('purchase-box-count').value) || 0,
        piece_count: parseInt(document.getElementById('purchase-piece-count').value) || 0,
        imei: document.getElementById('purchase-imei').value,
        invoice_number: document.getElementById('purchase-invoice').value,
        storage_status: document.getElementById('purchase-storage-status').value,
        customs_declaration: document.getElementById('purchase-customs').value,
        notes: document.getElementById('purchase-notes').value
    };
    
    try {
        let response;
        if (currentEditId) {
            response = await axios.put(`/api/purchases/${currentEditId}`, data);
        } else {
            response = await axios.post('/api/purchases', data);
        }
        
        if (response.data.success) {
            alert(currentEditId ? 'تم تحديث المشتريات بنجاح' : 'تم إضافة المشتريات بنجاح');
            closePurchaseModal();
            loadPurchases();
            loadDashboardStats();
        }
    } catch (error) {
        console.error('Error saving purchase:', error);
        alert('حدث خطأ في حفظ المشتريات');
    }
});

document.getElementById('sale-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const data = {
        sale_date: document.getElementById('sale-date').value,
        device_type: document.getElementById('sale-device-type').value,
        model: document.getElementById('sale-model').value,
        box_count: parseInt(document.getElementById('sale-box-count').value) || 0,
        piece_count: parseInt(document.getElementById('sale-piece-count').value) || 0,
        invoice_number: document.getElementById('sale-invoice').value,
        transfer_status: document.getElementById('sale-transfer-status').value,
        imei: document.getElementById('sale-imei').value,
        notes: document.getElementById('sale-notes').value
    };
    
    try {
        let response;
        if (currentEditId) {
            response = await axios.put(`/api/sales/${currentEditId}`, data);
        } else {
            response = await axios.post('/api/sales', data);
        }
        
        if (response.data.success) {
            alert(currentEditId ? 'تم تحديث المبيعات بنجاح' : 'تم إضافة المبيعات بنجاح');
            closeSaleModal();
            loadSales();
            loadDashboardStats();
        }
    } catch (error) {
        console.error('Error saving sale:', error);
        alert('حدث خطأ في حفظ المبيعات');
    }
});

// Helper function for status colors
function getStatusColor(status) {
    const colors = {
        'في المخزن': 'bg-green-100 text-green-800',
        'قيد المعالجة': 'bg-yellow-100 text-yellow-800',
        'تم البيع': 'bg-blue-100 text-blue-800',
        'تم النقل': 'bg-green-100 text-green-800',
        'قيد النقل': 'bg-yellow-100 text-yellow-800',
        'متأخر': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadDashboardStats();
    loadDeviceTypes();
    showPage('dashboard');
});
