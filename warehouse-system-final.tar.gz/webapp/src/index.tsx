import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

type Bindings = {
  DB: D1Database;
}

const app = new Hono<{ Bindings: Bindings }>()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './' }))

// ==================== API Routes ====================

// Initialize database tables
app.get('/api/init-db', async (c) => {
  try {
    const { DB } = c.env;

    // Create device_types table
    await DB.prepare(`
      CREATE TABLE IF NOT EXISTS device_types (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL UNIQUE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();

    // Create purchases table
    await DB.prepare(`
      CREATE TABLE IF NOT EXISTS purchases (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        purchase_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        imei TEXT,
        invoice_number TEXT,
        storage_status TEXT DEFAULT 'في المخزن',
        customs_declaration TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();

    // Create sales table
    await DB.prepare(`
      CREATE TABLE IF NOT EXISTS sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        invoice_number TEXT NOT NULL,
        transfer_status TEXT DEFAULT 'تم النقل',
        imei TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();

    // Create after_sales table
    await DB.prepare(`
      CREATE TABLE IF NOT EXISTS after_sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER,
        has_imei BOOLEAN DEFAULT 0,
        imei TEXT,
        customs_declaration TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
      )
    `).run();

    // Create indexes
    await DB.prepare(`CREATE INDEX IF NOT EXISTS idx_purchases_device_type ON purchases(device_type)`).run();
    await DB.prepare(`CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date)`).run();
    await DB.prepare(`CREATE INDEX IF NOT EXISTS idx_sales_device_type ON sales(device_type)`).run();
    await DB.prepare(`CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date)`).run();
    await DB.prepare(`CREATE INDEX IF NOT EXISTS idx_after_sales_sale_id ON after_sales(sale_id)`).run();

    // Insert default device types
    const deviceTypes = ['iPhone', 'Samsung', 'Xiaomi', 'Huawei', 'Oppo', 'Vivo'];
    for (const type of deviceTypes) {
      await DB.prepare(`INSERT OR IGNORE INTO device_types (name) VALUES (?)`).bind(type).run();
    }

    // Insert sample data
    await DB.prepare(`
      INSERT OR IGNORE INTO purchases (id, purchase_date, device_type, model, box_count, piece_count, imei, invoice_number, storage_status)
      VALUES (1, '2024-01-15', 'iPhone', 'iPhone 15 Pro', 5, 50, '123456789012345', 'INV-001', 'في المخزن')
    `).run();

    await DB.prepare(`
      INSERT OR IGNORE INTO purchases (id, purchase_date, device_type, model, box_count, piece_count, imei, invoice_number, storage_status)
      VALUES (2, '2024-01-20', 'Samsung', 'Galaxy S24', 3, 30, '234567890123456', 'INV-002', 'في المخزن')
    `).run();

    await DB.prepare(`
      INSERT OR IGNORE INTO purchases (id, purchase_date, device_type, model, box_count, piece_count, imei, invoice_number, storage_status)
      VALUES (3, '2024-02-01', 'Xiaomi', 'Redmi Note 13', 10, 100, '345678901234567', 'INV-003', 'في المخزن')
    `).run();

    await DB.prepare(`
      INSERT OR IGNORE INTO sales (id, sale_date, device_type, model, box_count, piece_count, invoice_number, transfer_status)
      VALUES (1, '2024-01-25', 'iPhone', 'iPhone 15 Pro', 2, 20, 'SALE-001', 'تم النقل')
    `).run();

    await DB.prepare(`
      INSERT OR IGNORE INTO sales (id, sale_date, device_type, model, box_count, piece_count, invoice_number, transfer_status)
      VALUES (2, '2024-02-05', 'Samsung', 'Galaxy S24', 1, 10, 'SALE-002', 'تم النقل')
    `).run();

    return c.json({ success: true, message: 'Database initialized successfully' });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get dashboard statistics
app.get('/api/dashboard/stats', async (c) => {
  try {
    const { DB } = c.env;

    // Total purchases (boxes and pieces)
    const totalPurchases = await DB.prepare(`
      SELECT 
        COUNT(*) as box_count,
        COALESCE(SUM(piece_count), 0) as piece_count
      FROM purchases
    `).first();

    // Total sales (boxes and pieces)
    const totalSales = await DB.prepare(`
      SELECT 
        COUNT(*) as box_count,
        COALESCE(SUM(piece_count), 0) as piece_count
      FROM sales
    `).first();

    // Remaining inventory
    const remaining = {
      box_count: (totalPurchases?.box_count || 0) - (totalSales?.box_count || 0),
      piece_count: (totalPurchases?.piece_count || 0) - (totalSales?.piece_count || 0)
    };

    return c.json({
      success: true,
      data: {
        purchases: totalPurchases,
        sales: totalSales,
        remaining: remaining
      }
    });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get all purchases
app.get('/api/purchases', async (c) => {
  try {
    const { DB } = c.env;
    const { results } = await DB.prepare(`
      SELECT * FROM purchases ORDER BY purchase_date DESC, id DESC
    `).all();

    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Add new purchase
app.post('/api/purchases', async (c) => {
  try {
    const { DB } = c.env;
    const body = await c.req.json();

    const result = await DB.prepare(`
      INSERT INTO purchases (
        purchase_date, device_type, model, box_count, piece_count,
        imei, invoice_number, storage_status, customs_declaration, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      body.purchase_date,
      body.device_type,
      body.model || null,
      body.box_count || 0,
      body.piece_count || 0,
      body.imei || null,
      body.invoice_number || null,
      body.storage_status || 'في المخزن',
      body.customs_declaration || null,
      body.notes || null
    ).run();

    return c.json({ success: true, data: { id: result.meta.last_row_id } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Update purchase
app.put('/api/purchases/:id', async (c) => {
  try {
    const { DB } = c.env;
    const id = c.req.param('id');
    const body = await c.req.json();

    await DB.prepare(`
      UPDATE purchases SET
        purchase_date = ?,
        device_type = ?,
        model = ?,
        box_count = ?,
        piece_count = ?,
        imei = ?,
        invoice_number = ?,
        storage_status = ?,
        customs_declaration = ?,
        notes = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      body.purchase_date,
      body.device_type,
      body.model || null,
      body.box_count || 0,
      body.piece_count || 0,
      body.imei || null,
      body.invoice_number || null,
      body.storage_status || 'في المخزن',
      body.customs_declaration || null,
      body.notes || null,
      id
    ).run();

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Delete purchase
app.delete('/api/purchases/:id', async (c) => {
  try {
    const { DB } = c.env;
    const id = c.req.param('id');

    await DB.prepare('DELETE FROM purchases WHERE id = ?').bind(id).run();

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get all sales
app.get('/api/sales', async (c) => {
  try {
    const { DB } = c.env;
    const { results } = await DB.prepare(`
      SELECT * FROM sales ORDER BY sale_date DESC, id DESC
    `).all();

    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Add new sale
app.post('/api/sales', async (c) => {
  try {
    const { DB } = c.env;
    const body = await c.req.json();

    const result = await DB.prepare(`
      INSERT INTO sales (
        sale_date, device_type, model, box_count, piece_count,
        invoice_number, transfer_status, imei, notes
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      body.sale_date,
      body.device_type,
      body.model || null,
      body.box_count || 0,
      body.piece_count || 0,
      body.invoice_number,
      body.transfer_status || 'تم النقل',
      body.imei || null,
      body.notes || null
    ).run();

    return c.json({ success: true, data: { id: result.meta.last_row_id } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Update sale
app.put('/api/sales/:id', async (c) => {
  try {
    const { DB } = c.env;
    const id = c.req.param('id');
    const body = await c.req.json();

    await DB.prepare(`
      UPDATE sales SET
        sale_date = ?,
        device_type = ?,
        model = ?,
        box_count = ?,
        piece_count = ?,
        invoice_number = ?,
        transfer_status = ?,
        imei = ?,
        notes = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).bind(
      body.sale_date,
      body.device_type,
      body.model || null,
      body.box_count || 0,
      body.piece_count || 0,
      body.invoice_number,
      body.transfer_status || 'تم النقل',
      body.imei || null,
      body.notes || null,
      id
    ).run();

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Delete sale
app.delete('/api/sales/:id', async (c) => {
  try {
    const { DB } = c.env;
    const id = c.req.param('id');

    await DB.prepare('DELETE FROM sales WHERE id = ?').bind(id).run();

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get reports by device type
app.get('/api/reports/by-device', async (c) => {
  try {
    const { DB } = c.env;

    const { results } = await DB.prepare(`
      SELECT 
        COALESCE(p.device_type, s.device_type) as device_type,
        COALESCE(SUM(p.box_count), 0) as purchase_boxes,
        COALESCE(SUM(p.piece_count), 0) as purchase_pieces,
        COALESCE(SUM(s.box_count), 0) as sale_boxes,
        COALESCE(SUM(s.piece_count), 0) as sale_pieces,
        (COALESCE(SUM(p.piece_count), 0) - COALESCE(SUM(s.piece_count), 0)) as remaining_pieces,
        CASE 
          WHEN COALESCE(SUM(p.piece_count), 0) = 0 THEN 0
          ELSE ROUND((CAST(COALESCE(SUM(s.piece_count), 0) AS REAL) / CAST(SUM(p.piece_count) AS REAL)) * 100, 2)
        END as sale_percentage
      FROM 
        (SELECT DISTINCT device_type FROM purchases 
         UNION 
         SELECT DISTINCT device_type FROM sales) dt
      LEFT JOIN purchases p ON dt.device_type = p.device_type
      LEFT JOIN sales s ON dt.device_type = s.device_type
      GROUP BY COALESCE(p.device_type, s.device_type)
      ORDER BY device_type
    `).all();

    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get device types for dropdown
app.get('/api/device-types', async (c) => {
  try {
    const { DB } = c.env;
    const { results } = await DB.prepare(`
      SELECT name FROM device_types ORDER BY name
    `).all();

    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// ==================== Main Page ====================
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>نظام إدارة المستودعات الذكي</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
            .nav-link { transition: all 0.3s; }
            .nav-link:hover { background: rgba(255,255,255,0.1); }
            .card { transition: transform 0.3s, box-shadow 0.3s; }
            .card:hover { transform: translateY(-5px); box-shadow: 0 10px 25px rgba(0,0,0,0.1); }
            .stat-card { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .stat-card-2 { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); }
            .stat-card-3 { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); }
            .btn-primary { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
            .btn-primary:hover { background: linear-gradient(135deg, #764ba2 0%, #667eea 100%); }
            .table-row:hover { background: #f8fafc; }
            .modal { display: none; }
            .modal.active { display: flex; }
        </style>
    </head>
    <body class="bg-gray-50">
        <!-- Navigation -->
        <nav class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-4">
                <div class="flex items-center justify-between">
                    <div class="flex items-center space-x-4 space-x-reverse">
                        <i class="fas fa-warehouse text-3xl"></i>
                        <h1 class="text-2xl font-bold">نظام إدارة المستودعات الذكي</h1>
                    </div>
                    <div class="flex space-x-4 space-x-reverse">
                        <button onclick="showPage('dashboard')" class="nav-link px-4 py-2 rounded-lg">
                            <i class="fas fa-chart-line ml-2"></i> لوحة التحكم
                        </button>
                        <button onclick="showPage('purchases')" class="nav-link px-4 py-2 rounded-lg">
                            <i class="fas fa-shopping-cart ml-2"></i> المشتريات
                        </button>
                        <button onclick="showPage('sales')" class="nav-link px-4 py-2 rounded-lg">
                            <i class="fas fa-dollar-sign ml-2"></i> المبيعات
                        </button>
                        <button onclick="showPage('reports')" class="nav-link px-4 py-2 rounded-lg">
                            <i class="fas fa-file-alt ml-2"></i> التقارير
                        </button>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="container mx-auto px-4 py-8">
            <!-- Dashboard Page -->
            <div id="dashboard-page" class="page">
                <h2 class="text-3xl font-bold mb-8 text-gray-800">
                    <i class="fas fa-chart-line ml-2 text-purple-600"></i>
                    لوحة التحكم والمؤشرات الرئيسية
                </h2>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <!-- Total Purchases -->
                    <div class="card stat-card text-white rounded-xl p-6 shadow-lg">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold">📦 إجمالي المشتريات</h3>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">البوكسات</span>
                                <span id="total-purchase-boxes" class="text-2xl font-bold">0</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">الحبات</span>
                                <span id="total-purchase-pieces" class="text-2xl font-bold">0</span>
                            </div>
                        </div>
                    </div>

                    <!-- Total Sales -->
                    <div class="card stat-card-2 text-white rounded-xl p-6 shadow-lg">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold">💰 إجمالي المبيعات</h3>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">البوكسات</span>
                                <span id="total-sale-boxes" class="text-2xl font-bold">0</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">الحبات</span>
                                <span id="total-sale-pieces" class="text-2xl font-bold">0</span>
                            </div>
                        </div>
                    </div>

                    <!-- Remaining Inventory -->
                    <div class="card stat-card-3 text-white rounded-xl p-6 shadow-lg">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold">📊 المخزون المتبقي</h3>
                        </div>
                        <div class="space-y-2">
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">البوكسات</span>
                                <span id="remaining-boxes" class="text-2xl font-bold">0</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm opacity-90">الحبات</span>
                                <span id="remaining-pieces" class="text-2xl font-bold">0</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Purchases Page -->
            <div id="purchases-page" class="page hidden">
                <div class="flex justify-between items-center mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">
                        <i class="fas fa-shopping-cart ml-2 text-purple-600"></i>
                        إدارة المشتريات
                    </h2>
                    <button onclick="openPurchaseModal()" class="btn-primary text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transition">
                        <i class="fas fa-plus ml-2"></i> إضافة مشتريات جديدة
                    </button>
                </div>

                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                                <tr>
                                    <th class="px-6 py-4 text-right">التاريخ</th>
                                    <th class="px-6 py-4 text-right">نوع الجهاز</th>
                                    <th class="px-6 py-4 text-right">الموديل</th>
                                    <th class="px-6 py-4 text-right">عدد البوكسات</th>
                                    <th class="px-6 py-4 text-right">عدد الحبات</th>
                                    <th class="px-6 py-4 text-right">رقم الفاتورة</th>
                                    <th class="px-6 py-4 text-right">حالة المخزون</th>
                                    <th class="px-6 py-4 text-center">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody id="purchases-table-body" class="divide-y divide-gray-200">
                                <!-- Data will be inserted here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Sales Page -->
            <div id="sales-page" class="page hidden">
                <div class="flex justify-between items-center mb-8">
                    <h2 class="text-3xl font-bold text-gray-800">
                        <i class="fas fa-dollar-sign ml-2 text-purple-600"></i>
                        إدارة المبيعات
                    </h2>
                    <button onclick="openSaleModal()" class="btn-primary text-white px-6 py-3 rounded-lg shadow-lg hover:shadow-xl transition">
                        <i class="fas fa-plus ml-2"></i> إضافة مبيعات جديدة
                    </button>
                </div>

                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                                <tr>
                                    <th class="px-6 py-4 text-right">التاريخ</th>
                                    <th class="px-6 py-4 text-right">نوع الجهاز</th>
                                    <th class="px-6 py-4 text-right">الموديل</th>
                                    <th class="px-6 py-4 text-right">عدد البوكسات</th>
                                    <th class="px-6 py-4 text-right">عدد الحبات</th>
                                    <th class="px-6 py-4 text-right">رقم الفاتورة</th>
                                    <th class="px-6 py-4 text-right">حالة النقل</th>
                                    <th class="px-6 py-4 text-center">الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody id="sales-table-body" class="divide-y divide-gray-200">
                                <!-- Data will be inserted here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Reports Page -->
            <div id="reports-page" class="page hidden">
                <h2 class="text-3xl font-bold mb-8 text-gray-800">
                    <i class="fas fa-file-alt ml-2 text-purple-600"></i>
                    التقارير التفصيلية
                </h2>

                <div class="bg-white rounded-xl shadow-lg overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full">
                            <thead class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                                <tr>
                                    <th class="px-6 py-4 text-right">نوع الجهاز</th>
                                    <th class="px-6 py-4 text-right">مشتريات (بوكس)</th>
                                    <th class="px-6 py-4 text-right">مشتريات (حبة)</th>
                                    <th class="px-6 py-4 text-right">مبيعات (بوكس)</th>
                                    <th class="px-6 py-4 text-right">مبيعات (حبة)</th>
                                    <th class="px-6 py-4 text-right">المتبقي (حبة)</th>
                                    <th class="px-6 py-4 text-right">نسبة البيع %</th>
                                    <th class="px-6 py-4 text-center">الحالة</th>
                                </tr>
                            </thead>
                            <tbody id="reports-table-body" class="divide-y divide-gray-200">
                                <!-- Data will be inserted here -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Purchase Modal -->
        <div id="purchase-modal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50">
            <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-4 rounded-t-xl">
                    <h3 class="text-2xl font-bold">
                        <i class="fas fa-shopping-cart ml-2"></i>
                        <span id="purchase-modal-title">إضافة مشتريات جديدة</span>
                    </h3>
                </div>
                <form id="purchase-form" class="p-6 space-y-4">
                    <input type="hidden" id="purchase-id">
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">التاريخ *</label>
                            <input type="date" id="purchase-date" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">نوع الجهاز *</label>
                            <input type="text" id="purchase-device-type" required list="device-types-list" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                            <datalist id="device-types-list"></datalist>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">الموديل</label>
                        <input type="text" id="purchase-model" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">عدد البوكسات</label>
                            <input type="number" id="purchase-box-count" min="0" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">عدد الحبات</label>
                            <input type="number" id="purchase-piece-count" min="0" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">IMEI</label>
                            <input type="text" id="purchase-imei" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">رقم الفاتورة</label>
                            <input type="text" id="purchase-invoice" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">حالة المخزون</label>
                        <select id="purchase-storage-status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                            <option value="في المخزن">في المخزن</option>
                            <option value="قيد المعالجة">قيد المعالجة</option>
                            <option value="تم البيع">تم البيع</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">البيان الجمركي</label>
                        <input type="text" id="purchase-customs" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">ملاحظات</label>
                        <textarea id="purchase-notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"></textarea>
                    </div>

                    <div class="flex justify-end space-x-4 space-x-reverse pt-4">
                        <button type="button" onclick="closePurchaseModal()" class="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                            <i class="fas fa-times ml-2"></i> إلغاء
                        </button>
                        <button type="submit" class="btn-primary text-white px-6 py-2 rounded-lg hover:shadow-xl transition">
                            <i class="fas fa-save ml-2"></i> حفظ
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sale Modal -->
        <div id="sale-modal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center z-50">
            <div class="bg-white rounded-xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
                <div class="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 py-4 rounded-t-xl">
                    <h3 class="text-2xl font-bold">
                        <i class="fas fa-dollar-sign ml-2"></i>
                        <span id="sale-modal-title">إضافة مبيعات جديدة</span>
                    </h3>
                </div>
                <form id="sale-form" class="p-6 space-y-4">
                    <input type="hidden" id="sale-id">
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">التاريخ *</label>
                            <input type="date" id="sale-date" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">نوع الجهاز *</label>
                            <input type="text" id="sale-device-type" required list="device-types-list-sale" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                            <datalist id="device-types-list-sale"></datalist>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">الموديل</label>
                        <input type="text" id="sale-model" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">عدد البوكسات</label>
                            <input type="number" id="sale-box-count" min="0" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">عدد الحبات</label>
                            <input type="number" id="sale-piece-count" min="0" value="0" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">رقم الفاتورة *</label>
                            <input type="text" id="sale-invoice" required class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                        </div>
                        
                        <div>
                            <label class="block text-gray-700 font-semibold mb-2">حالة النقل</label>
                            <select id="sale-transfer-status" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                                <option value="تم النقل">تم النقل</option>
                                <option value="قيد النقل">قيد النقل</option>
                                <option value="متأخر">متأخر</option>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">IMEI</label>
                        <input type="text" id="sale-imei" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    </div>

                    <div>
                        <label class="block text-gray-700 font-semibold mb-2">ملاحظات</label>
                        <textarea id="sale-notes" rows="3" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"></textarea>
                    </div>

                    <div class="flex justify-end space-x-4 space-x-reverse pt-4">
                        <button type="button" onclick="closeSaleModal()" class="px-6 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition">
                            <i class="fas fa-times ml-2"></i> إلغاء
                        </button>
                        <button type="submit" class="btn-primary text-white px-6 py-2 rounded-lg hover:shadow-xl transition">
                            <i class="fas fa-save ml-2"></i> حفظ
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script src="/static/app.js"></script>
    </body>
    </html>
  `)
})

export default app
