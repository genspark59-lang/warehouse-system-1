import { sql } from '@vercel/postgres';

export const db = {
  async query(query: string, params: any[] = []) {
    try {
      const result = await sql.query(query, params);
      return result;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  },

  async get(query: string, params: any[] = []) {
    try {
      const result = await sql.query(query, params);
      return result.rows[0] || null;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  },

  async all(query: string, params: any[] = []) {
    try {
      const result = await sql.query(query, params);
      return result.rows;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  },

  async run(query: string, params: any[] = []) {
    try {
      const result = await sql.query(query, params);
      return result;
    } catch (error) {
      console.error('Database error:', error);
      throw error;
    }
  }
};

// Initialize database tables
export async function initializeDatabase() {
  try {
    // Create device_types table
    await db.run(`
      CREATE TABLE IF NOT EXISTS device_types (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create purchases table
    await db.run(`
      CREATE TABLE IF NOT EXISTS purchases (
        id SERIAL PRIMARY KEY,
        purchase_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        imei TEXT,
        invoice_number TEXT,
        storage_status TEXT DEFAULT 'في المخزن',
        customs_declaration TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create sales table
    await db.run(`
      CREATE TABLE IF NOT EXISTS sales (
        id SERIAL PRIMARY KEY,
        sale_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        invoice_number TEXT NOT NULL,
        transfer_status TEXT DEFAULT 'تم النقل',
        imei TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create after_sales table
    await db.run(`
      CREATE TABLE IF NOT EXISTS after_sales (
        id SERIAL PRIMARY KEY,
        sale_id INTEGER REFERENCES sales(id) ON DELETE CASCADE,
        has_imei BOOLEAN DEFAULT false,
        imei TEXT,
        customs_declaration TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create indexes
    await db.run(`CREATE INDEX IF NOT EXISTS idx_purchases_device_type ON purchases(device_type)`);
    await db.run(`CREATE INDEX IF NOT EXISTS idx_purchases_date ON purchases(purchase_date)`);
    await db.run(`CREATE INDEX IF NOT EXISTS idx_sales_device_type ON sales(device_type)`);
    await db.run(`CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date)`);
    await db.run(`CREATE INDEX IF NOT EXISTS idx_after_sales_sale_id ON after_sales(sale_id)`);

    // Insert default device types
    const deviceTypes = ['iPhone', 'Samsung', 'Xiaomi', 'Huawei', 'Oppo', 'Vivo'];
    for (const type of deviceTypes) {
      await db.run(`INSERT INTO device_types (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`, [type]);
    }

    console.log('Database initialized successfully');
    return { success: true };
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}
