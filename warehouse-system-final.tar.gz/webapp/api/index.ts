import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { handle } from 'hono/vercel';
import { sql } from '@vercel/postgres';

const app = new Hono().basePath('/api');

// Enable CORS
app.use('/*', cors());

// Database helper functions
const db = {
  async get(query: string, params: any[] = []) {
    const result = await sql.query(query, params);
    return result.rows[0] || null;
  },
  async all(query: string, params: any[] = []) {
    const result = await sql.query(query, params);
    return result.rows;
  },
  async run(query: string, params: any[] = []) {
    return await sql.query(query, params);
  }
};

// Initialize database
app.get('/init-db', async (c) => {
  try {
    // Create tables
    await db.run(`
      CREATE TABLE IF NOT EXISTS device_types (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await db.run(`
      CREATE TABLE IF NOT EXISTS purchases (
        id SERIAL PRIMARY KEY,
        purchase_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        imei TEXT,
        invoice_number TEXT,
        storage_status TEXT DEFAULT 'في المخزن',
        customs_declaration TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await db.run(`
      CREATE TABLE IF NOT EXISTS sales (
        id SERIAL PRIMARY KEY,
        sale_date DATE NOT NULL,
        device_type TEXT NOT NULL,
        model TEXT,
        box_count INTEGER NOT NULL DEFAULT 0,
        piece_count INTEGER NOT NULL DEFAULT 0,
        invoice_number TEXT NOT NULL,
        transfer_status TEXT DEFAULT 'تم النقل',
        imei TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Insert device types
    const deviceTypes = ['iPhone', 'Samsung', 'Xiaomi', 'Huawei', 'Oppo', 'Vivo'];
    for (const type of deviceTypes) {
      await db.run(`INSERT INTO device_types (name) VALUES ($1) ON CONFLICT (name) DO NOTHING`, [type]);
    }

    return c.json({ success: true, message: 'Database initialized' });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Dashboard stats
app.get('/dashboard/stats', async (c) => {
  try {
    const purchases = await db.get(`
      SELECT COUNT(*) as box_count, COALESCE(SUM(piece_count), 0) as piece_count FROM purchases
    `);
    
    const sales = await db.get(`
      SELECT COUNT(*) as box_count, COALESCE(SUM(piece_count), 0) as piece_count FROM sales
    `);

    const remaining = {
      box_count: Number(purchases?.box_count || 0) - Number(sales?.box_count || 0),
      piece_count: Number(purchases?.piece_count || 0) - Number(sales?.piece_count || 0)
    };

    return c.json({ success: true, data: { purchases, sales, remaining } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get purchases
app.get('/purchases', async (c) => {
  try {
    const results = await db.all(`SELECT * FROM purchases ORDER BY purchase_date DESC, id DESC`);
    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Add purchase
app.post('/purchases', async (c) => {
  try {
    const body = await c.req.json();
    const result = await db.run(`
      INSERT INTO purchases (purchase_date, device_type, model, box_count, piece_count, imei, invoice_number, storage_status, customs_declaration, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `, [
      body.purchase_date,
      body.device_type,
      body.model || null,
      body.box_count || 0,
      body.piece_count || 0,
      body.imei || null,
      body.invoice_number || null,
      body.storage_status || 'في المخزن',
      body.customs_declaration || null,
      body.notes || null
    ]);

    return c.json({ success: true, data: { id: result.rows[0].id } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Update purchase
app.put('/purchases/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();

    await db.run(`
      UPDATE purchases SET
        purchase_date = $1, device_type = $2, model = $3, box_count = $4, piece_count = $5,
        imei = $6, invoice_number = $7, storage_status = $8, customs_declaration = $9, notes = $10,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $11
    `, [
      body.purchase_date, body.device_type, body.model, body.box_count, body.piece_count,
      body.imei, body.invoice_number, body.storage_status, body.customs_declaration, body.notes, id
    ]);

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Delete purchase
app.delete('/purchases/:id', async (c) => {
  try {
    const id = c.req.param('id');
    await db.run('DELETE FROM purchases WHERE id = $1', [id]);
    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Get sales
app.get('/sales', async (c) => {
  try {
    const results = await db.all(`SELECT * FROM sales ORDER BY sale_date DESC, id DESC`);
    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Add sale
app.post('/sales', async (c) => {
  try {
    const body = await c.req.json();
    const result = await db.run(`
      INSERT INTO sales (sale_date, device_type, model, box_count, piece_count, invoice_number, transfer_status, imei, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING id
    `, [
      body.sale_date, body.device_type, body.model, body.box_count, body.piece_count,
      body.invoice_number, body.transfer_status, body.imei, body.notes
    ]);

    return c.json({ success: true, data: { id: result.rows[0].id } });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Update sale
app.put('/sales/:id', async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();

    await db.run(`
      UPDATE sales SET
        sale_date = $1, device_type = $2, model = $3, box_count = $4, piece_count = $5,
        invoice_number = $6, transfer_status = $7, imei = $8, notes = $9,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $10
    `, [
      body.sale_date, body.device_type, body.model, body.box_count, body.piece_count,
      body.invoice_number, body.transfer_status, body.imei, body.notes, id
    ]);

    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Delete sale
app.delete('/sales/:id', async (c) => {
  try {
    const id = c.req.param('id');
    await db.run('DELETE FROM sales WHERE id = $1', [id]);
    return c.json({ success: true });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Reports
app.get('/reports/by-device', async (c) => {
  try {
    const results = await db.all(`
      SELECT 
        COALESCE(p.device_type, s.device_type) as device_type,
        COUNT(DISTINCT p.id) as purchase_boxes,
        COALESCE(SUM(p.piece_count), 0) as purchase_pieces,
        COUNT(DISTINCT s.id) as sale_boxes,
        COALESCE(SUM(s.piece_count), 0) as sale_pieces,
        COALESCE(SUM(p.piece_count), 0) - COALESCE(SUM(s.piece_count), 0) as remaining_pieces,
        CASE 
          WHEN COALESCE(SUM(p.piece_count), 0) = 0 THEN 0
          ELSE ROUND((CAST(COALESCE(SUM(s.piece_count), 0) AS NUMERIC) / CAST(SUM(p.piece_count) AS NUMERIC)) * 100, 2)
        END as sale_percentage
      FROM 
        (SELECT DISTINCT device_type FROM purchases 
         UNION 
         SELECT DISTINCT device_type FROM sales) dt
      LEFT JOIN purchases p ON dt.device_type = p.device_type
      LEFT JOIN sales s ON dt.device_type = s.device_type
      GROUP BY COALESCE(p.device_type, s.device_type)
      ORDER BY device_type
    `);

    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

// Device types
app.get('/device-types', async (c) => {
  try {
    const results = await db.all(`SELECT name FROM device_types ORDER BY name`);
    return c.json({ success: true, data: results });
  } catch (error: any) {
    return c.json({ success: false, error: error.message }, 500);
  }
});

export default handle(app);
