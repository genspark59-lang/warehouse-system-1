-- بيانات تجريبية للمشتريات
INSERT INTO purchases (purchase_date, device_type, model, box_count, piece_count, imei, invoice_number, storage_status) VALUES 
  ('2024-01-15', 'iPhone', 'iPhone 15 Pro', 5, 50, '123456789012345', 'INV-001', 'في المخزن'),
  ('2024-01-20', 'Samsung', 'Galaxy S24', 3, 30, '234567890123456', 'INV-002', 'في المخزن'),
  ('2024-02-01', 'Xiaomi', 'Redmi Note 13', 10, 100, '345678901234567', 'INV-003', 'في المخزن'),
  ('2024-02-10', 'iPhone', 'iPhone 14', 4, 40, '456789012345678', 'INV-004', 'في المخزن'),
  ('2024-02-15', 'Huawei', 'P60 Pro', 2, 20, '567890123456789', 'INV-005', 'في المخزن');

-- بيانات تجريبية للمبيعات
INSERT INTO sales (sale_date, device_type, model, box_count, piece_count, invoice_number, transfer_status) VALUES 
  ('2024-01-25', 'iPhone', 'iPhone 15 Pro', 2, 20, 'SALE-001', 'تم النقل'),
  ('2024-02-05', 'Samsung', 'Galaxy S24', 1, 10, 'SALE-002', 'تم النقل'),
  ('2024-02-12', 'Xiaomi', 'Redmi Note 13', 3, 30, 'SALE-003', 'تم النقل');
